#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>
#include <conio.h>
#include<string.h>

int cont = 0;

typedef struct lista{
    char c;
    lista *prox;
}Lista;

typedef struct pilhaa{
    Lista *prim;
}Pilha;

Pilha * cria(){
    Pilha p = (Pilha)malloc(sizeof(Pilha));
    p->prim = NULL;
    return p;
}

void push(Pilha *p,char v){
    Lista x = (Lista)malloc(sizeof(Lista));
    x->c = v;
    x->prox = p->prim;
    p->prim = x;

}

char pop(Pilha *p){
    Lista *x;
    x = p->prim;
    char valor = x->c;
    p->prim = x->prox;
    free(x);

    return valor;
}

void verificaPalindromo(Pilha *p){
	int i;
	bool valor;
	char *palavra, *inversa;
	palavra = (char *) malloc(cont * sizeof(char));
	inversa = (char *) malloc(cont * sizeof(char));
	
	for(i=0;i<cont;i++){
		palavra[i] = pop(p);
	}	
	
	strcpy(inversa, palavra);
	strrev(inversa);
	valor = strcmp(palavra, inversa);
	
	if (valor == 0)
	   printf("\nA palavra %s � pal�ndroma\n", palavra);
	else
	   printf("\nA palavra %s n�o � pal�ndroma\n", palavra);
	cont = 0;
	
}


int main() {
	
	setlocale(LC_ALL, "");
	int x;
	char ca;
	Pilha *p = cria();
	
	printf("***MENU***\n");
	printf("Digite 1 para realizar um PUSH\n");
	printf("Digite 2 para realizar um POP\n");
	printf("Digite 3 para verificar palindromo\n");
	printf("Digite 0 sair\n");
	
	do{

		scanf("%d",&x);
		
		switch(x){
			case 0:
				printf("Saindo\n");
			break;
			case 1:
				printf("Digite o caracter\n");
				scanf("%s",&ca);
				push(p,ca);
				x = 1;
				cont++;
			break;
			case 2:
				ca = pop(p);
				printf("%c",ca);
				cont--;
			break;
			case 3:
				verificaPalindromo(p);
			break;
			default:
				printf("Opcao invalida...");
		}
		
	}while(x != 0);
	
	
	
	return 0;
}
