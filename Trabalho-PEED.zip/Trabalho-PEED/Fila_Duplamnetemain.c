#include <iostream>
#include <stdio.h>
#include <stdlib.h>

typedef struct lista{
	int x;
	struct lista* ant;
	struct lista* prox;
}Lista;

typedef struct fila{
	Lista* ini;
	Lista* fim;
}Fila;


static Lista* inserir(Lista* fim, int x){
	Lista* n = (Lista*) malloc(sizeof(Lista));
	n->x = x;
	n->prox = NULL;
	n->ant = fim;
	if(fim != NULL){
		fim->prox = n;
	}
	return n;
}

static Lista* retirar(Lista* ini){
	Lista* n = ini->prox;
	if(n != NULL){
		n->ant = NULL;
	}
	return n;
}

void fila_inserir(Fila* f, int x){
	f->fim = inserir(f->fim,x);
	if(f->ini == NULL){
		f->ini = f->fim;
	}
}

int fila_retira(Fila* f){
	int x;
	if(f->ini == NULL){
		printf("fila vazia \n");
		exit(1);
	}
	x = f->ini->x;
	f->ini = retirar(f->ini);
	if(f->ini == NULL){
		f->fim = NULL;
	}	
	
	return x;
	
}


int main(){
	
	Fila* fila = (Fila*) malloc(sizeof(Fila));
	fila->ini = NULL;
	fila->fim = NULL;
	
	fila_inserir(fila,10);
	fila_inserir(fila,5);
	fila_inserir(fila,4);
	fila_inserir(fila,8);
	fila_retira(fila);
	fila_inserir(fila,9);
	fila_retira(fila);
	fila_retira(fila);


	
	printf("%d\n",fila->ini->x);
	printf("%d\n",fila->fim->x);
	printf("%d\n",fila->ini->prox->x);

	return 0;
}
